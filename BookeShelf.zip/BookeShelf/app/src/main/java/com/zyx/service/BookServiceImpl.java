package com.zyx.service;

import android.content.Context;

import com.zyx.bean.Book;
import com.zyx.bean.Shelf;
import com.zyx.bean.Tag;
import com.zyx.comparator.authorComparator;
import com.zyx.comparator.nameComparator;
import com.zyx.comparator.publisherComparator;
import com.zyx.comparator.timeComparator;
import com.zyx.dao.BookDao;
import com.zyx.dao.BookDaoImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BookServiceImpl implements BookService {
    BookDao bookDao = new BookDaoImpl();

    @Override
    public List<Book> SelectByTag(Tag tag, List<Book> books) {
        int id = tag.getId();
        List<Book> res = new ArrayList<>();
        for (Book b:books){
            if(b.getTags()!=null&&b.getTags().contains(id)){
                res.add(b);
            }
        }
        return res;
    }

    @Override
    public void SortByAuthor(List<Book> books) {
       Collections.sort(books,new authorComparator());
    }

    @Override
    public void SortByName(List<Book> books) {
        Collections.sort(books,new nameComparator());
    }

    @Override
    public void SortByTime(List<Book> books) {
        Collections.sort(books,new timeComparator());
    }

    @Override
    public void SortByPublisher(List<Book> books) {
        Collections.sort(books,new publisherComparator());
    }

    @Override
    public boolean UpdateBook(Context context, Book book) {
        ArrayList<Book> books = (ArrayList<Book>) GetBooks(context);

        for(int i=0;i<books.size();i++){
            if(books.get(i).getId() == book.getId()) {
                books.set(i,book);
                SaveBooks(context,books);
                return  true;
            }
        }
        return false;
    }

    @Override
    public List<Book> SelectByShelf(Shelf shelf, List<Book> books) {
        int id = shelf.getId();
        List<Book> res = new ArrayList<>();
        for (Book b:books){
            if(b.getShelfId()==id)
                res.add(b);
        }
        return res;
    }

    @Override
    public void SaveBooks(Context context, List<Book> books) {
        bookDao.saveBook(books,context);
    }

    @Override
    public List<Book> GetBooks(Context context) {
        return bookDao.readBook(context);
    }

    @Override
    public List<Book> SearchBook(List<Book> list, String s) {
        List<Book> res = new ArrayList<>();

        for(Book b : list) {
            if(b.getName().indexOf(s) != -1 || b.getAuthor().indexOf(s) != -1 || b.getPublisher().indexOf(s) != -1)
                res.add(b);
        }
        return res;
    }

    @Override
    public int InsertBook(Context context,Book book) {
       return bookDao.InsertBook(context,book);
    }
}
