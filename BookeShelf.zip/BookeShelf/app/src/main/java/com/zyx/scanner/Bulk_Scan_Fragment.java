package com.zyx.scanner;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.zxing.Result;
import com.zyx.bean.Book;
import com.zyx.bookeshelf.R;
import com.zyx.scanner.Bulk_List_Fragment;

import java.util.ArrayList;
import java.util.List;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

import static com.zyx.scanner.Bulk_List_Fragment.list;

public class Bulk_Scan_Fragment extends Fragment implements ZXingScannerView.ResultHandler {
    private static final String TAG = "BatchScanFragment";
    private static final String FLASH_STATE = "FLASH_STATE";

    private ZXingScannerView mScannerView;
    public static boolean mFlash = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_batch_scan, container, false);
        setHasOptionsMenu(true);
        if (savedInstanceState != null) {
            mFlash = savedInstanceState.getBoolean(FLASH_STATE, false);
        } else {
            mFlash = false;
        }
        ViewGroup viewGroup = (ViewGroup) view.findViewById(R.id.batch_add_frame_scan);
        mScannerView = new ZXingScannerView(getActivity());
        mScannerView.setAutoFocus(true);
        mScannerView.setFlash(mFlash);
        mScannerView.setResultHandler(this);
        viewGroup.addView(mScannerView);
        return view;
    }

    private void addBook(final String isbn) {
        if(list == null)
            list = new ArrayList<>();
        Bulk_List_Fragment.notifys();
        Book a = new Book();
        a.setIsbn(isbn);
        a.setName("1");

        list.add(a);
    }

    @Override
    public void handleResult(Result rawResult) {
        Log.i(TAG, "ScanResult Contents = " + rawResult.getText() + ", Format = " + rawResult.getBarcodeFormat().toString());
        addBook(rawResult.getText());

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mScannerView.resumeCameraPreview(Bulk_Scan_Fragment.this);
            }
        }, 2000);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(FLASH_STATE, mFlash);
    }

    @Override
    public void onResume() {
        super.onResume();
        mScannerView.setResultHandler(this);
        mScannerView.setAutoFocus(true);
        mScannerView.setFlash(mFlash);
        mScannerView.startCamera();
    }

    @Override
    public void onPause() {
        super.onPause();
        mScannerView.stopCamera();
    }
}

